"use client";

import { useSearchParams } from "next/navigation";
import { useEffect, useRef } from "react";
import React, { Suspense } from "react";

import { BASE_API_URL } from "@/shared/constants/endpoint";
import logger from "@/shared/libs/Logger";

const InstagramCallback = () => {
  const params = useSearchParams();
  const code = params?.get("code") ?? "";
  const error_reason = params?.get("error_reason") ?? "";
  const initialized = useRef(false);

  useEffect(() => {
    logger(code, "code");

    if (!initialized.current && code) {
      initialized.current = true;
      const redirectUrl = `${process.env.NEXT_PUBLIC_APP_URL}${process.env.NEXT_PUBLIC_BASE_PATH}/callback/instagram.html`;

      const getProfile = async () => {
        const body = {
          code: code,
          redirectUrl: redirectUrl,
        };

        fetch(
          `${
            BASE_API_URL[process.env.NEXT_PUBLIC_API_URL as string]
          }/social/media/instagram/profile`,
          {
            method: "POST",
            headers: {
              Accept: "application/json",
              "Content-Type": "application/json",
              "x-api-key": "ASoVCHCnwgSHOAEKMlMecbiDYWowHQSUZOMiqhKYZIgc",
            },
            body: JSON.stringify(body),
          }
        )
          .then((response) => response.json())
          .then((data) => {
            // window?.opener?.postMessage({ ...data, socmedCode: 'ig' }, '*');
            localStorage.setItem(
              "socmed_message",
              JSON.stringify({ ...data, socmedCode: "ig" })
            );
            localStorage.removeItem("socmed_message");
            window.close();
          })
          .catch((error) => {
            // window?.opener?.postMessage(
            //   { error: error, socmedCode: 'ig' },
            //   '*',
            // );
            localStorage.setItem(
              "socmed_message",
              JSON.stringify({ error: error, socmedCode: "ig" })
            );
            localStorage.removeItem("socmed_message");
            window.close();
          });
      };
      getProfile();
    }
  }, [code]);

  useEffect(() => {
    if (!initialized.current && error_reason === "user_denied") {
      initialized.current = true;
      // window?.opener?.postMessage(
      //   {
      //     error: 'user_denied',
      //     message:
      //       'Sesuai dengan kebijakan Instagram yang terbaru, Anda perlu mengubah akun Instagram Anda ke tipe Profesional untuk dapat mengikuti program ini. Terima kasih atas pengertiannya!',
      //   },
      //   '*',
      // );
      localStorage.setItem(
        "socmed_message",
        JSON.stringify({
          error: "user_denied",
          message:
            "Sesuai dengan kebijakan Instagram yang terbaru, Anda perlu mengubah akun Instagram Anda ke tipe Profesional untuk dapat mengikuti program ini. Terima kasih atas pengertiannya!",
        })
      );
      localStorage.removeItem("socmed_message");
      window.close();
    }
  }, [error_reason]);

  return (
    <div>
      {/* {code && <div>Processing Instagram Login...</div>}
      {error_reason == 'user_denied' && (
        <>
        <HeaderCallback />
          <div className={cn(
              'container',
              'flex flex-col justify-center gap-8',
              'py-12',
              '-mt-[32px] py-[64px] h-[calc(100dvh-240px)]',
            )}>
            <div className='mb-5 text-center text-lg font-bold md:text-xl'>
              Sesuai dengan kebijakan Instagram yang terbaru, Anda perlu mengubah
              akun Instagram Anda ke tipe Profesional untuk dapat mengikuti
              program ini. Terima kasih atas pengertiannya!
            </div>

            <div className='flex items-center justify-center pt-[20px]'>
              <Button
                type='button'
                onClick={() => {
                        window?.parent?.postMessage(
        {
          error: 'user_denied',
          message:
            'Sesuai dengan kebijakan Instagram yang terbaru, Anda perlu mengubah akun Instagram Anda ke tipe Profesional untuk dapat mengikuti program ini. Terima kasih atas pengertiannya!',
        },
        '*',
      );
      window.close();
                }}
                className='button-primary rounded-full hover:m-[-2px_-5px] lg:!px-[32px] hover:lg:!px-[37px]'
              >
                Kembali
              </Button>
            </div>
          </div>
        <Footer />
        </>
      )} */}
      <div>Processing Instagram Login...</div>
    </div>
  );
};

const page = () => {
  return (
    <Suspense>
      <InstagramCallback></InstagramCallback>
    </Suspense>
  );
};

export default page;
