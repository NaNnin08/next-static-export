import React, { useCallback, useEffect, useRef, useState } from "react";
import FacebookLogin from "react-facebook-login/dist/facebook-login-render-props";
import { useFieldArray, useFormContext } from "react-hook-form";
import { FaCheck, FaTrashAlt } from "react-icons/fa";
import { FaPlus } from "react-icons/fa6";

import ModalComponent from "@/components/ModalComponent";
import ModalConfirmation from "@/components/ModalConfirmation";
import { Box } from "@/components/ui/box";
import { Button } from "@/components/ui/button";
import { InputField } from "@/components/ui/inputField";
import { InputStringOnlyNumber } from "@/components/ui/inputStringOnlyNumber";
import { toast } from "@/components/ui/use-toast";
import logger from "@/shared/libs/Logger";
import { cn } from "@/shared/utils/Helpers";

import SelectSocmedIcon from "./SelectSocmedIcon";

const SocialMediaForm = ({ refferal }: { refferal: string }) => {
  const { control, getFieldState, getValues, setValue } = useFormContext();
  const { fields, append, remove } = useFieldArray({
    control,
    name: "socialMedia.socmedData",
  });
  const fbBtnRef = useRef<HTMLButtonElement>(null);

  const [selectedIndexSocmed, setSelectedIndexSocmed] = useState(-1);
  const [modalError, setModalError] = useState({ isOpen: false, text: "" });
  const [isConfirmationIg, setIsConfirmationIg] = useState(false);

  function isStepCompleted() {
    const socialMedia = getValues("socialMedia");

    const requiredFields = [
      { name: "socmedData", fields: ["socmedId", "accountName"] },
    ];

    // Check required fields like socmedId and accountName
    const isSocmedDataValid = requiredFields.every((section) =>
      socialMedia?.[section.name]?.every((item: any, index: number) =>
        section.fields.every((field) => {
          const fieldValue = item?.[field];
          const fieldState = getFieldState(
            `socialMedia.${section.name}.${index}.${field}`
          );
          return Boolean(fieldValue) && !fieldState.error;
        })
      )
    );

    // Check if codeMarketing or codeAffiliate exist and are valid
    const optionalFields = ["codeMarketing", "codeAffiliate"];
    const isOptionalFieldsValid = optionalFields.every((field) => {
      const fieldValue = getValues(`socialMedia.${field}`);
      if (fieldValue) {
        const fieldState = getFieldState(`socialMedia.${field}`);
        return Boolean(fieldValue) && !fieldState.error; // Ensure non-empty and no errors if they exist
      }
      return true; // If not present, consider valid
    });

    return isSocmedDataValid && isOptionalFieldsValid;
  }

  useEffect(() => {
    if (refferal) {
      // setValue(`socialMedia.codeAffiliate`, refferal);
      logger(refferal, "referral code");
    }
  }, [refferal]);

  const updateSocMedItem = useCallback(
    (value: any) => {
      logger(value, "updateSocMedItem");

      const socmedData = getValues(
        `socialMedia.socmedData.${selectedIndexSocmed}`
      );
      // const index = socmedData.findIndex(
      //   (item: any) =>
      //     item.socmedId === value.socmedId && item.accountName == '',
      // );
      // ?DONT FORGET TO ADD socmedId here
      setValue(`socialMedia.socmedData.${selectedIndexSocmed}`, {
        socmedCode: value.socmedCode,
        dataId: socmedData?.dataId || "",
        socmedId: socmedData?.socmedId || "",
        accountName: value.username,
      });
      setSelectedIndexSocmed(-1);
      toast({
        variant: "default",
        description: "Berhasil menghubungkan akun.",
      });
    },
    [getValues, selectedIndexSocmed, setValue]
  );

  const handleFacebookLoginSuccess = (response: any) => {
    if ("name" in response) {
      updateSocMedItem({
        socmedCode: "fb",
        id: response.id,
        username: response.name,
      });
    } else {
      toast({
        variant: "destructive",
        title: "Gagal menghubungkan akun!",
      });
    }
  };

  // useEffect(() => {
  //   if (mutationValidateRegister?.isError) {
  //     const errorResponse = mutationValidateRegister?.error?.response?.data;
  //     const errorMessage = errorResponse?.message || '';

  //     if (errorMessage.includes('sosial')) {
  //       setValue('socialMedia.socmedData', [{ socmedId: 2, accountName: '' }]);
  //     }
  //   }
  // }, [mutationValidateRegister?.isError, setValue]);

  useEffect(() => {
    const handleMessage = (event: MessageEvent) => {
      try {
        if (event?.data?.socmedCode) {
          logger(event, "received message");
          if (event?.data?.status === 200) {
            logger(event.data.data, "received data");
            updateSocMedItem({
              ...event.data.data,
              socmedCode: event?.data?.socmedCode,
            });
          } else {
            toast({
              variant: "destructive",
              title: "Gagal menghubungkan akun!",
            });
          }
        }

        if (event?.data?.error === "user_denied") {
          setModalError({ isOpen: true, text: event?.data?.message ?? "" });
        }
      } catch (error) {}
    };

    function message_receive(ev: any) {
      if (ev.key == "socmed_message") {
        const socmed_message = JSON.parse(ev.newValue);

        if (!socmed_message) return;

        try {
          if (socmed_message?.socmedCode) {
            logger(socmed_message, "received message");
            if (socmed_message?.status === 200) {
              logger(socmed_message.data, "received data");
              updateSocMedItem({
                ...socmed_message.data,
                socmedCode: socmed_message?.socmedCode,
              });
            } else {
              toast({
                variant: "destructive",
                title: "Gagal menghubungkan akun!",
              });
            }
          }

          if (socmed_message?.error === "user_denied") {
            setModalError({
              isOpen: true,
              text: socmed_message?.message ?? "",
            });
          }
        } catch (error) {}
      }
    }

    window.addEventListener("message", handleMessage);
    window.addEventListener("storage", message_receive);

    return () => {
      window.removeEventListener("message", handleMessage);
      window.removeEventListener("storage", message_receive);
    };
  }, [updateSocMedItem]);

  const loginInstagram = () => {
    const clientId = process.env.NEXT_PUBLIC_IG_CLIENT_ID;
    const redirectUri = encodeURIComponent(
      `${process.env.NEXT_PUBLIC_APP_URL}${process.env.NEXT_PUBLIC_BASE_PATH}/callback/instagram.html` ||
        ""
    );
    const scope = encodeURIComponent("instagram_business_basic");
    // const state = encodeURIComponent('secureRandomState');

    const authUrl = `/oauth/authorize?enable_fb_login=1&client_id=${clientId}&redirect_uri=${redirectUri}&response_type=code&scope=${scope}`; //&state=${state}
    const uriAuthUrl = encodeURIComponent(authUrl);
    const width = 600;
    const height = 700;
    const left = (window.innerWidth - width) / 2;
    const top = (window.innerHeight - height) / 2;

    window.open(
      `${process.env.NEXT_PUBLIC_APP_URL}${
        process.env.NEXT_PUBLIC_BASE_PATH
      }/redirect?link=${encodeURIComponent(
        `https://instagram.com/accounts/login/?source=webapp&force_classic_login&next=${uriAuthUrl}`
      )}`,
      "Instagram Login",
      `width=${width},height=${height},top=${top},left=${left}`
    );
  };

  const loginTiktok = () => {
    const clientId = process.env.NEXT_PUBLIC_TIKTOK_CLIENT_ID;
    const redirectUri = encodeURI(
      `${process.env.NEXT_PUBLIC_APP_URL}${process.env.NEXT_PUBLIC_BASE_PATH}/callback/tiktok.html` ||
        ""
    );
    const scope = encodeURIComponent("user.info.profile,user.info.stats");
    const state = encodeURIComponent("secureRandomState");

    const authUrl = `https://www.tiktok.com/v2/auth/authorize?client_key=${clientId}&response_type=code&scope=${scope}&redirect_uri=${redirectUri}&state=${state}`;

    const width = 600;
    const height = 700;
    const left = (window.innerWidth - width) / 2;
    const top = (window.innerHeight - height) / 2;

    window.open(
      authUrl,
      "Tiktok Login",
      `width=${width},height=${height},top=${top},left=${left}`
    );
  };

  const openLoginSocmed = (index: number) => {
    // if (getValues(`socialMedia.socmedData.${index}.accountId`)) return;
    setSelectedIndexSocmed(index);
    const id = getValues(`socialMedia.socmedData.${index}.socmedCode`);
    switch (id) {
      case "ig":
        // loginInstagram();
        setIsConfirmationIg(true);
        break;
      case "tiktok":
        loginTiktok();
        break;
      case "fb":
        fbBtnRef.current?.click();
        break;
      default:
        break;
    }
  };

  const getReadOnlyValue = (nameField: string): boolean => {
    const value = getValues(nameField);

    if (value) return !["x", "youtube"].includes(value);

    return true;
  };

  return (
    <ol className="relative text-secondary">
      <div>
        <li
          className={cn(
            "m-0 border-s-2 pb-6 pl-6",
            "border-primary",
            isStepCompleted() ? "border-primary" : "border-[#D8D8D8]"
          )}
        >
          <span
            className={cn(
              "absolute -start-4 flex items-center justify-center",
              "h-8 w-8 rounded-full border-[1.5px] border-[#D8D8D8]",
              "bg-primary",
              isStepCompleted()
                ? "bg-primary text-white"
                : "bg-white text-primary",
              "ring-8 ring-[#EEEEEE]"
            )}
          >
            {isStepCompleted() && <FaCheck className="text-white" />}
          </span>
          <div className="text-lg font-bold md:text-xl">
            Hubungkan dengan media sosial Anda
          </div>

          <div className="mt-6">
            {fields.map((field, index) => (
              <Box key={field.id}>
                <div className="mb-4 flex w-full items-center gap-2">
                  <div
                    className={cn(
                      "",
                      `${
                        getFieldState(
                          `socialMedia.socmedData.${index}.accountName`
                        ).error
                          ? "mb-7"
                          : ""
                      }`
                    )}
                  >
                    <SelectSocmedIcon
                      name={`socialMedia.socmedData.${index}`}
                      // defaultValue={`socialMedia.socmedData.${index}` as any}
                      // disabled={getValues(
                      //   `socialMedia.socmedData.${index}.accountId`,
                      // )}
                      valueEffect={[
                        {
                          name: `socialMedia.socmedData.${index}.accountName`,
                          value: "",
                        },
                      ]}
                    />
                  </div>

                  <div className="w-full">
                    <InputField
                      name={`socialMedia.socmedData.${index}.accountName`}
                      placeholder={
                        getValues(`socialMedia.socmedData.${index}`)
                          ?.socmedCode === "youtube"
                          ? "Cth: https//youtube.com/affiliator123"
                          : getValues(`socialMedia.socmedData.${index}`)
                              ?.socmedCode === "x"
                          ? "Cth: https//x(twitter).com/affiliator123"
                          : "username"
                      }
                      mandatory
                      readOnly={getReadOnlyValue(
                        `socialMedia.socmedData.${index}.socmedCode`
                      )}
                      onClick={() => {
                        getReadOnlyValue(
                          `socialMedia.socmedData.${index}.socmedCode`
                        ) && openLoginSocmed(index);
                      }}
                    />
                  </div>
                  {index > 0 && (
                    <FaTrashAlt
                      onClick={() => remove(index)}
                      className={cn(
                        "h-6 w-6 cursor-pointer text-primary",
                        `${
                          getFieldState(
                            `socialMedia.socmedData.${index}.accountName`
                          ).error
                            ? "mb-7"
                            : ""
                        }`
                      )}
                    />
                  )}
                </div>
                {index === 0 && (
                  <div className="mb-4 text-sm font-bold text-primary">
                    Wajib memiliki minimum 1 akun media sosial
                  </div>
                )}
              </Box>
            ))}

            <Button
              type="button"
              variant="link"
              onClick={() => {
                append({ socmedCode: "ig", accountName: "" });
              }}
              className="w-full text-lg font-normal"
            >
              <span>Tambah media sosial lain</span>
              <FaPlus className="ml-2 h-4 w-4 text-primary" />
            </Button>

            <hr className="my-5 border border-[#D8D8D8]" />

            <Box className="flex flex-col gap-y-5">
              <div className="text-lg font-bold md:text-xl">
                Kode Tenaga Pemasar Referensi (optional)
              </div>

              <InputStringOnlyNumber
                name="socialMedia.codeMarketing"
                placeholder="Kode Tenaga Pemasar"
                maxLength={8}
              />
              {/* //!TODO hidden affiliate */}
              {/* <div className=''>
                <InputField
                  name='socialMedia.codeAffiliate'
                  placeholder='Kode Affiliate Temanmu'
                  disable={refferal ? true : false}
                />
              </div> */}
            </Box>
          </div>
        </li>
      </div>

      <FacebookLogin
        appId={process.env.NEXT_PUBLIC_FB_CLIENT_ID || ""}
        autoLoad={false}
        fields=""
        callback={handleFacebookLoginSuccess}
        disableMobileRedirect={true}
        render={(renderProps) => (
          <button ref={fbBtnRef} type="button" onClick={renderProps.onClick} />
        )}
      />

      <ModalComponent
        isOpen={modalError.isOpen}
        onConfirm={() => {
          setModalError({ isOpen: false, text: "" });
        }}
        header="Gagal Menyambungkan Akun"
        textConfrim="Kembali"
      >
        {modalError.text}
      </ModalComponent>

      <ModalConfirmation
        isOpen={isConfirmationIg}
        onCancel={() => setIsConfirmationIg(false)}
        onConfirm={() => {
          setIsConfirmationIg(false);
          loginInstagram();
        }}
        confirmLabel="Oke"
        className="!z-[999]"
      >
        <div className="my-4 text-secondary">
          Anda perlu akun instagram profesional untuk menghubungkan instagram
          Anda ke Cuap Bareng Prudential.
          <br />
          <br />
          Akun profesional memberikan Anda akses ke berbagai fitur tambahan
          untuk mengembangkan bisnis Anda.
          <br />
          <br />
          Ubah akun Instagram Anda ke akun profesional melalui &quot;
          <b>Edit Profile</b>&quot; di Instagram
        </div>
      </ModalConfirmation>
    </ol>
  );
};

export default SocialMediaForm;
